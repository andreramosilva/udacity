### Design:
<details about implementation such as data structures and algorithms used>
for this problem I used a dicionary and a list. The idea was to create a list to keep track on the calls made on the items on my cache so I can easily delete the one tha was least used when needed because to search.

### Time Complexity:
<Big O notation with brief explanation>

I search only on the dicionary so is O(1) to find the data


### Space Complexity:
<Big O notation with brief explanation>
is constanst because the input size does not change the amout of space required on each execution.
O(1)