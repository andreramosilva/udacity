### Design:
<details about implementation such as data structures and algorithms used>
For this one I convert first to a list so I can perform in a more simple way the operations;


### Time Complexity:
<Big O notation with brief explanation>

To convert is o(n) and o(n) as well to get the intersection because I have to check the whole input (when I do intersection) so I belive leads to o(2n), when i do union still o(n) to convert, but i belive is o(n) also get the 2 arrays combined and transform it in a set so probably o(n**2)



### Space Complexity:
<Big O notation with brief explanation>
o(n)