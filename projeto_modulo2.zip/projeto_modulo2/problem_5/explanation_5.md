# i used a "linked list type of structure to create this, to add a block or get , first or last block is o(1) but to find a specific block would be o(n)
