### Design:
<details about implementation such as data structures and algorithms used>
I used a linked list type of structure to create this, to add a block or get , first or last block is o(1) but to find a specific block would be o(n)

### Time Complexity:
<Big O notation with brief explanation>
To add a block or get , first or last block is o(1)
but to find a specific block would be o(n)


### Space Complexity:
<Big O notation with brief explanation>

o(n)