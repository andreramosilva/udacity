### Design:
<details about implementation such as data structures and algorithms used>
For this problem I used arrays to return the lists of paths. that way seems a little more organized. 


### Time Complexity:
<Big O notation with brief explanation>

because I have to check for every single possibility do a for 
and call a recusive function with a for inside i belive that is o(2**n)
### Space Complexity:
<Big O notation with brief explanation>
i belive that because of the amout of operations it takes and because i have to search for every possibility always incresing by 2 is o(2**n) just like the time complexity