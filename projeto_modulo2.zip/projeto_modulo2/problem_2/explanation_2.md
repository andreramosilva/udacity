# for problem 2 i used an array to return the lists of paths , because i have to check for every single possibility do a for and call a recusive function with a for inside i belive that is o(n\*\*2)
