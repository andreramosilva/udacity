### Design:
<details about implementation such as data structures and algorithms used>
Recusively i check for every single possibility

### Time Complexity:
<Big O notation with brief explanation>
o(2**n)

### Space Complexity:
<Big O notation with brief explanation>
because i have to recursively look in to every single possibility I belive is o(2**n)
