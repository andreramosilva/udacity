# for problem for i went simple and i check if user in group. group is an array so is going to be O(n) will check the whole array to find the user.
