### Design:
<details about implementation such as data structures and algorithms used>
For this problem my first step is to order the array using quicksort.
Then I use the array as an stack poping the numbers from higher to 
lower and creating the number that would have the maximum sum.

### Time Complexity:
<Big O notation with brief explanation>
I belive is (n log n) 

### Space Complexity:
<Big O notation with brief explanation>
here i belive is O(1)  cuz i save some space by ordering the array itself.