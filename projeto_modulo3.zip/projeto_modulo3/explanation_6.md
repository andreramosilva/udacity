
<details about implementation such as data structures and algorithms used>
for this problem i used the approach of a linear search where i
 try to find the smallest and largest number

### Time Complexity:
<Big O notation with brief explanation>
o(n)

### Space Complexity:
<Big O notation with brief explanation>
o(1) is constant because i only used constant couple helper variables 
and use them to compare there is no extra space being used.