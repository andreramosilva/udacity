### Design:
<details about implementation such as data structures and algorithms used>
I don't know if applies but I will explain anyway. 
Basicly I follow the instructions and created a Trie class
adding what was requested. 

### Time Complexity:
<Big O notation with brief explanation>
well I belive for the operations requested using a Trie would be
bacause in the worst case i would have to transverse the whole Trie to 
add or to search so would be(where l is the length of the word and amout of words): 
O(n * l)

### Space Complexity:
<Big O notation with brief explanation>
like i described above the space complexity would also be o(n*l)