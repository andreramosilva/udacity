### Design:
<details about implementation such as data structures and algorithms used>
I don't know if applies but I will explain anyway. 
Basicly I follow the instructions and created a Trie class
adding what was requested. 

### Time Complexity:
<Big O notation with brief explanation>
well I belive for the operations requested using a Trie would be 
O(n log n)

### Space Complexity:
<Big O notation with brief explanation>
well I belive for the operations requested using a Trie would be 
O(n log n)