### Design:
<details about implementation such as data structures and algorithms used>
I can always expect 0,1 or 2 in the array so I just need to know 
who comes first and last. I used a for loop to transverse only one time,
 make 3 lists and return them in order.

### Time Complexity:
<Big O notation with brief explanation>
O(n) because i transverse the input once.

### Space Complexity:
<Big O notation with brief explanation>
O(n**2) because I have to create 3 small 
arrays that together are the size of the original array