### Design:
<details about implementation such as data structures and algorithms used>
Transverse only when is needed and is only one transversal 

### Time Complexity:
<Big O notation with brief explanation>
o(log n)

### Space Complexity:
<Big O notation with brief explanation>
o(log n)