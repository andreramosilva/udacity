### Design:
<details about implementation such as data structures and algorithms used>
For problem 1 I tried a simple approach calculating the square root of the number.

### Time Complexity:
<Big O notation with brief explanation>
O(1) constant time

### Space Complexity:
<Big O notation with brief explanation>
o(1)