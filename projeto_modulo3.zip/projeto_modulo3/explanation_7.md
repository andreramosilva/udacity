
<details about implementation such as data structures and algorithms used>
Basicly the idea is very close to
how would work the autocomplete ou to find words and etc... 
is just a different application using routes.

### Time Complexity:
<Big O notation with brief explanation>
o(N) because I have to "transverse" everytime to add or find

### Space Complexity:
<Big O notation with brief explanation>
o(n)