
<details about implementation such as data structures and algorithms used>
Basicly the idea is very close to
how would work the autocomplete ou to find words and etc... 
is just a different application using routes.

### Time Complexity:
<Big O notation with brief explanation>
o(N) because I have to "transverse" everytime to add or find, 
for example the method lookup i have to walk the tree in order.

### Space Complexity:
<Big O notation with brief explanation>
o(n) as well because the handler method give a little more efficiency 
when storing the paths that way saves some space.