### Design:
<details about implementation such as data structures and algorithms used>
I tried to apply binary search on this problem, where i search 
recursively, breaking down the problem until 
I find the solution.

### Time Complexity:
<Big O notation with brief explanation>
O(log N ) binary search would be O(log n) but i have to 
search every time i split both sides so i belive is O(N log N) where N is the 
amount i have to search until i find it every time i break the problem in two.


### Space Complexity:
<Big O notation with brief explanation>
O(log N )